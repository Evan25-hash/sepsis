"""
Replikasi arsitektur Transformer dari Cell 6C notebook skripsi.
"""

import math
import torch
import torch.nn as nn


D_MODEL_TF  = 32
N_HEADS_TF  = 2
N_LAYERS_TF = 1
DIM_FF_TF   = 64
DROPOUT     = 0.4
MAX_LEN_PE  = 4096


class SinusoidalPositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = MAX_LEN_PE):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float()
            * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(pos * div_term)
        pe[:, 1::2] = torch.cos(pos * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, : x.size(1), :]


class TransformerModel(nn.Module):
    def __init__(
        self,
        input_size: int,
        d_model:   int = D_MODEL_TF,
        n_heads:   int = N_HEADS_TF,
        n_layers:  int = N_LAYERS_TF,
        dim_ff:    int = DIM_FF_TF,
        dropout: float = DROPOUT,
    ):
        super().__init__()
        self.input_proj = nn.Linear(input_size, d_model)
        self.pos_enc    = SinusoidalPositionalEncoding(d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=dim_ff,
            dropout=dropout, activation="relu",
            batch_first=True, norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, n_layers)
        self.dropout = nn.Dropout(dropout)
        self.fc      = nn.Linear(d_model, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        T = x.size(1)
        h = self.input_proj(x)
        h = self.pos_enc(h)
        causal_mask = torch.triu(
            torch.ones(T, T, dtype=torch.bool, device=x.device),
            diagonal=1,
        )
        h = self.encoder(h, mask=causal_mask)
        pooled = h.mean(dim=1).squeeze(0)
        return self.fc(self.dropout(pooled)).squeeze(0)
