"""
Validasi Excel input multi-pasien dengan per-row error messages.

Workflow validasi:
1. Preflight: kolom required ada, sheet ada
2. Per-row validation: range check, NaN policy, etc.
3. Per-patient validation: hr continuity, minimum 1 value per feature
"""

from typing import Dict, List, Tuple
import pandas as pd


# Hard ranges (observed training data bounds)
HARD_RANGES = {
    "lactate":      (0.0,   40.0),
    "baseexcess":   (-50.0, 50.0),
    "inr":          (0.0,   25.0),
    "aniongap":     (0.0,   60.0),
    "sbp":          (0.0,   399.0),
    "pt":           (0.0,   150.0),
    "totalco2":     (0.0,   60.0),
    "urine_output": (0.0,   2000.0),
    "fio2":         (21.0,  100.0),
    "bicarbonate":  (0.0,   60.0),
    "platelet":     (0.0,   1500.0),
    "map":          (0.0,   299.0),
    "creatinine":   (0.0,   150.0),
}

SOFT_RANGES = {
    "lactate":      (0.5,   2.2,    "mmol/L"),
    "baseexcess":   (-2.0,  2.0,    "mEq/L"),
    "inr":          (0.8,   1.2,    ""),
    "aniongap":     (8.0,   16.0,   "mEq/L"),
    "sbp":          (90.0,  140.0,  "mmHg"),
    "pt":           (11.0,  13.5,   "detik"),
    "totalco2":     (23.0,  29.0,   "mEq/L"),
    "urine_output": (30.0,  200.0,  "mL/jam"),
    "fio2":         (21.0,  40.0,   "%"),
    "bicarbonate":  (22.0,  29.0,   "mEq/L"),
    "platelet":     (150.0, 450.0,  "rb/µL"),
    "map":          (70.0,  100.0,  "mmHg"),
    "creatinine":   (0.6,   1.2,    "mg/dL"),
}

CRITICAL_FLAGS = {
    "lactate":      ("ge", 2.0,  "Laktat tinggi"),
    "map":          ("lt", 65.0, "Tekanan darah rendah"),
    "creatinine":   ("ge", 2.0,  "Kreatinin tinggi"),
    "platelet":     ("lt", 100.0, "Trombosit rendah"),
    "urine_output": ("lt", 30.0, "Produksi urin rendah"),
}

# Display labels (Indonesian, klinis-friendly)
FEATURE_DISPLAY = {
    "lactate":      ("Laktat",            "mmol/L"),
    "baseexcess":   ("Base Excess",       "mEq/L"),
    "inr":          ("INR",               ""),
    "aniongap":     ("Anion Gap",         "mEq/L"),
    "sbp":          ("Tekanan Sistolik",  "mmHg"),
    "pt":           ("PT (Waktu Protrombin)", "detik"),
    "totalco2":     ("Total CO₂",         "mEq/L"),
    "urine_output": ("Produksi Urin",     "mL/jam"),
    "fio2":         ("FiO₂",              "%"),
    "bicarbonate":  ("Bikarbonat",        "mEq/L"),
    "platelet":     ("Trombosit",         "rb/µL"),
    "map":          ("Tekanan Rata-rata", "mmHg"),
    "creatinine":   ("Kreatinin",         "mg/dL"),
}


REQUIRED_COLUMNS = ["stay_id", "hr"] + list(HARD_RANGES.keys())
MAX_PATIENTS = 20


def preflight_check(df: pd.DataFrame) -> List[str]:
    """
    Cek kolom dan struktur dasar. Returns list of error messages (kosong = ok).
    """
    errors = []

    if len(df) == 0:
        errors.append("File Excel kosong, tidak ada data sama sekali.")
        return errors

    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        cols_display = ", ".join(missing_cols)
        errors.append(f"Kolom berikut tidak ditemukan di file: {cols_display}")
        return errors

    # Cek stay_id — tidak boleh kosong, NaN, atau hanya spasi
    sid_col = df["stay_id"]
    sid_is_empty = sid_col.isna() | (
        sid_col.astype(str).str.strip().isin(["", "nan", "None"])
    )
    if sid_is_empty.any():
        errors.append("Kolom 'stay_id' tidak boleh ada yang kosong.")

    n_patients = df["stay_id"].nunique()
    if n_patients > MAX_PATIENTS:
        errors.append(
            f"File berisi {n_patients} pasien. "
            f"Maksimal {MAX_PATIENTS} pasien per file."
        )

    return errors


def validate_row(row: pd.Series, row_index: int) -> List[str]:
    """
    Validasi satu baris data. Returns list of error messages untuk baris ini.
    """
    errors = []

    # Cek hr
    hr_val = row.get("hr")
    if pd.isna(hr_val):
        errors.append("Kolom 'hr' kosong")
    elif not isinstance(hr_val, (int, float)) or hr_val < 0:
        errors.append("Kolom 'hr' harus angka >= 0")

    # Cek range per fitur — hanya untuk nilai non-NaN
    for feat, (lo, hi) in HARD_RANGES.items():
        if feat not in row.index:
            continue
        val = row[feat]
        if pd.isna(val):
            continue  # NaN OK, akan di-impute
        try:
            val_f = float(val)
        except (TypeError, ValueError):
            display_name, unit = FEATURE_DISPLAY[feat]
            errors.append(f"{display_name}: bukan angka")
            continue
        if val_f < lo or val_f > hi:
            display_name, unit = FEATURE_DISPLAY[feat]
            unit_str = f" {unit}" if unit else ""
            errors.append(f"{display_name}: {val_f}{unit_str} diluar batas wajar ({lo}–{hi})")

    return errors


def validate_patient(patient_df: pd.DataFrame, stay_id, feature_cols: list) -> List[str]:
    """
    Validasi per-patient (struktur sequence, fitur kosong).
    Returns list of patient-level error messages.
    """
    errors = []

    # Cek hr harus bilangan bulat (integer)
    hr_raw = patient_df["hr"].dropna()
    non_integer = hr_raw[hr_raw != hr_raw.round()]
    if len(non_integer) > 0:
        errors.append(
            "Jam (kolom 'hr') harus berupa bilangan bulat, "
            "tidak boleh desimal. Contoh: 0, 1, 2, 3."
        )

    # Cek hr continuity (no gap, sequential)
    hrs = hr_raw.round().astype(int).sort_values().tolist()
    if len(hrs) > 0:
        expected = list(range(hrs[0], hrs[0] + len(hrs)))
        if hrs != expected:
            errors.append(
                "Jam (kolom 'hr') harus berurutan tanpa lompatan. "
                f"Contoh yang benar: 0, 1, 2, 3..."
            )
        if len(set(hrs)) != len(hrs):
            errors.append("Jam (kolom 'hr') tidak boleh duplikat.")

    # Cek setiap fitur minimal 1 nilai
    empty_features = []
    for feat in feature_cols:
        if feat not in patient_df.columns:
            continue
        if patient_df[feat].isna().all():
            display_name, _ = FEATURE_DISPLAY.get(feat, (feat, ""))
            empty_features.append(display_name)

    if empty_features:
        names = ", ".join(empty_features)
        errors.append(
            f"Fitur berikut tidak memiliki data sama sekali: {names}. "
            f"Tambahkan minimal 1 nilai pada salah satu jam."
        )

    return errors


def validate_all(df: pd.DataFrame) -> Dict:
    """
    Validasi lengkap.
    Returns dict:
        preflight_errors: list of file-level errors (langsung tampilkan)
        row_errors:       dict[row_index] -> list of error strings
        patient_errors:   dict[stay_id] -> list of error strings
        is_valid:         bool (semua bersih?)
        n_total_rows:     int
        n_valid_rows:     int
        n_invalid_rows:   int
        patient_summary:  dict[stay_id] -> {n_rows, n_errors, is_valid}
    """
    feature_cols = list(HARD_RANGES.keys())

    # Preflight
    preflight = preflight_check(df)
    if preflight:
        return {
            "preflight_errors": preflight,
            "row_errors":       {},
            "patient_errors":   {},
            "is_valid":         False,
            "n_total_rows":     len(df),
            "n_valid_rows":     0,
            "n_invalid_rows":   len(df),
            "patient_summary":  {},
        }

    # Row-level validation
    row_errors = {}
    for idx, row in df.iterrows():
        errs = validate_row(row, idx)
        if errs:
            row_errors[idx] = errs

    # Patient-level validation
    patient_errors = {}
    patient_summary = {}
    for stay_id, patient_df in df.groupby("stay_id"):
        errs = validate_patient(patient_df, stay_id, feature_cols)
        if errs:
            patient_errors[stay_id] = errs

        # Count row errors per patient
        n_row_errs = sum(1 for idx in patient_df.index if idx in row_errors)
        patient_summary[stay_id] = {
            "n_rows":     len(patient_df),
            "n_row_errs": n_row_errs,
            "has_patient_errs": len(errs) > 0,
            "is_valid":   n_row_errs == 0 and len(errs) == 0,
        }

    n_invalid_rows = len(row_errors)
    is_valid = (
        len(preflight) == 0 and
        len(row_errors) == 0 and
        len(patient_errors) == 0
    )

    return {
        "preflight_errors": [],
        "row_errors":       row_errors,
        "patient_errors":   patient_errors,
        "is_valid":         is_valid,
        "n_total_rows":     len(df),
        "n_valid_rows":     len(df) - n_invalid_rows,
        "n_invalid_rows":   n_invalid_rows,
        "patient_summary":  patient_summary,
    }


def is_abnormal(feature: str, value: float) -> Tuple[bool, str]:
    """Cek apakah nilai abnormal."""
    if feature not in SOFT_RANGES or pd.isna(value):
        return False, "normal"
    lo, hi, _ = SOFT_RANGES[feature]
    if value < lo:
        return True, "low"
    if value > hi:
        return True, "high"
    return False, "normal"


def is_critical(feature: str, value: float) -> bool:
    """Cek apakah nilai kritis."""
    if feature not in CRITICAL_FLAGS or pd.isna(value):
        return False
    op, threshold, _ = CRITICAL_FLAGS[feature]
    if op == "ge":
        return value >= threshold
    if op == "lt":
        return value < threshold
    return False
