"""
Inference engine v3 — multi-pasien dengan lazy compute + cache.
"""

import json
from pathlib import Path
from typing import Tuple, Optional, Dict, List

import joblib
import numpy as np
import pandas as pd
import torch

from transformer_arch import TransformerModel
from imputation import impute_dataframe, compute_missingness


# Threshold
THRESHOLD_HIGH   = 0.70
THRESHOLD_MEDIUM = 0.30

# Lead-time zones (untuk visual indicator)
ZONE_STRONG   = 6   # hr 0-6: window terkuat (AUPRC ≤ 0.70)
ZONE_GOOD     = 24  # hr 7-24: window kuat
ZONE_MODERATE = 48  # hr 25-48: window sedang
# hr > 48: window lemah


ASSETS_DIR     = Path(__file__).parent / "assets"
CHECKPOINT_DIR = ASSETS_DIR / "checkpoints"
DEMO_DIR       = ASSETS_DIR / "demos"

MODEL_PATH        = CHECKPOINT_DIR / "best_transformer.pt"
SCALER_PATH       = CHECKPOINT_DIR / "scaler.pkl"
FEATURE_COLS_PATH = CHECKPOINT_DIR / "feature_cols_final.json"


# Feature ranking (dari Cell 9 permutation importance)
FEATURE_RANKING = [
    {"feature": "lactate",      "importance": 0.09391, "std": 0.00088},
    {"feature": "baseexcess",   "importance": 0.02468, "std": 0.00111},
    {"feature": "fio2",         "importance": 0.01817, "std": 0.00042},
    {"feature": "sbp",          "importance": 0.01788, "std": 0.00044},
    {"feature": "creatinine",   "importance": 0.01067, "std": 0.00091},
    {"feature": "totalco2",     "importance": 0.00698, "std": 0.00104},
    {"feature": "pt",           "importance": 0.00513, "std": 0.00078},
    {"feature": "map",          "importance": 0.00499, "std": 0.00057},
    {"feature": "inr",          "importance": 0.00447, "std": 0.00057},
    {"feature": "platelet",     "importance": 0.00428, "std": 0.00021},
    {"feature": "bicarbonate",  "importance": 0.00386, "std": 0.00084},
    {"feature": "urine_output", "importance": 0.00180, "std": 0.00089},
    {"feature": "aniongap",     "importance": -0.00196, "std": 0.00118},
]


_MODEL: Optional[TransformerModel] = None
_SCALER = None
_FEATURE_COLS: Optional[list] = None


def load_artifacts() -> Tuple[TransformerModel, object, list]:
    """Load model, scaler, feature columns. Cached."""
    global _MODEL, _SCALER, _FEATURE_COLS

    if _MODEL is not None:
        return _MODEL, _SCALER, _FEATURE_COLS

    with open(FEATURE_COLS_PATH) as f:
        _FEATURE_COLS = json.load(f)

    _SCALER = joblib.load(SCALER_PATH)

    ckpt = torch.load(MODEL_PATH, map_location="cpu", weights_only=False)
    _MODEL = TransformerModel(input_size=len(_FEATURE_COLS))
    _MODEL.load_state_dict(ckpt["state_dict"])
    _MODEL.eval()

    return _MODEL, _SCALER, _FEATURE_COLS


def get_risk_level(prob: float) -> str:
    if prob >= THRESHOLD_HIGH:
        return "TINGGI"
    if prob >= THRESHOLD_MEDIUM:
        return "SEDANG"
    return "RENDAH"


def get_zone(hr: int) -> str:
    """Lead-time zone untuk visual indicator."""
    if hr <= ZONE_STRONG:
        return "strong"
    if hr <= ZONE_GOOD:
        return "good"
    if hr <= ZONE_MODERATE:
        return "moderate"
    return "weak"


def predict_patient(patient_df: pd.DataFrame) -> Dict:
    """
    Pipeline lengkap untuk 1 pasien.
    Returns:
        success, refused, features_all_empty,
        df_imputed, imputed_mask, missingness,
        trajectory, imputation_report, truncated_pe
    """
    model, scaler, feature_cols = load_artifacts()

    missingness = compute_missingness(patient_df, feature_cols)
    df_imputed, imputed_mask, imp_report = impute_dataframe(patient_df, feature_cols)

    if imp_report["refused"]:
        return {
            "success":             False,
            "features_all_empty":  imp_report["features_all_empty"],
            "df_imputed":          df_imputed,
            "imputed_mask":        imputed_mask,
            "missingness":         missingness,
            "trajectory":          None,
            "imputation_report":   imp_report,
            "truncated_pe":        False,
        }

    # Batas panjang sequence untuk inference.
    # MAX_LEN_PE (4096) adalah kapasitas teknis positional encoding, tapi
    # inference growing-window berskala O(T²) — pada 2000+ jam waktunya
    # melebihi 45 detik. ICU stay > 1000 jam (>41 hari) sangat langka dan
    # di luar cakupan data training. Kalau melebihi, ambil 1000 jam terakhir
    # (paling relevan secara klinis untuk prediksi terkini).
    SEQ_CAP = 1000
    truncated_pe = False
    if len(df_imputed) > SEQ_CAP:
        df_imputed   = df_imputed.iloc[-SEQ_CAP:].reset_index(drop=True)
        imputed_mask = imputed_mask.iloc[-SEQ_CAP:].reset_index(drop=True)
        truncated_pe = True

    # Scale & inference
    # Pakai DataFrame (bukan .values) supaya scaler dapat memverifikasi
    # nama & urutan fitur. df_imputed[feature_cols] menjamin urutan kolom
    # konsisten dengan urutan saat scaler di-fit.
    raw_df   = df_imputed[feature_cols]
    scaled   = scaler.transform(raw_df)
    scaled_t = torch.tensor(scaled, dtype=torch.float32)

    probs = []
    with torch.no_grad():
        for T in range(len(df_imputed)):
            seq = scaled_t[: T + 1].unsqueeze(0)
            logit = model(seq)
            prob = torch.sigmoid(logit).item()
            probs.append(prob)

    trajectory = pd.DataFrame({
        "hr":      df_imputed["hr"].astype(int).values,
        "prob":    probs,
        "seq_len": range(1, len(df_imputed) + 1),
    })
    trajectory["risk_level"] = trajectory["prob"].apply(get_risk_level)
    trajectory["zone"]       = trajectory["hr"].apply(get_zone)

    return {
        "success":             True,
        "features_all_empty":  [],
        "df_imputed":          df_imputed,
        "imputed_mask":        imputed_mask,
        "missingness":         missingness,
        "trajectory":          trajectory,
        "imputation_report":   imp_report,
        "truncated_pe":        truncated_pe,
    }


def get_top_k_features(k: int = 5) -> list:
    return FEATURE_RANKING[:k]


def get_all_features() -> list:
    return FEATURE_RANKING
