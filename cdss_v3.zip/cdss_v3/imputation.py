"""
Imputasi time-series — replikasi exact Cell 4B notebook skripsi.
"""

from typing import Dict, Tuple
import numpy as np
import pandas as pd


# Kategori fitur dari notebook
VITAL_FEATS = ["sbp", "map"]
URINE_FEATS = ["urine_output"]
LAB_FEATS = [
    "lactate", "baseexcess", "inr", "aniongap", "pt",
    "totalco2", "fio2", "bicarbonate", "platelet", "creatinine",
]


def categorize_feature(feat: str) -> str:
    if feat in VITAL_FEATS:
        return "vital"
    if feat in URINE_FEATS:
        return "urine"
    if feat in LAB_FEATS:
        return "lab"
    return "unknown"


def compute_missingness(df: pd.DataFrame, feature_cols: list) -> pd.DataFrame:
    """Hitung % missing per fitur."""
    rows = []
    n_total = len(df)
    for feat in feature_cols:
        if feat not in df.columns:
            rows.append({
                "feature":     feat,
                "category":    categorize_feature(feat),
                "n_total":     n_total,
                "n_missing":   n_total,
                "pct_missing": 100.0,
            })
            continue
        n_missing = int(df[feat].isna().sum())
        rows.append({
            "feature":     feat,
            "category":    categorize_feature(feat),
            "n_total":     n_total,
            "n_missing":   n_missing,
            "pct_missing": round(n_missing / n_total * 100, 1) if n_total > 0 else 0.0,
        })
    return pd.DataFrame(rows)


def impute_dataframe(df: pd.DataFrame, feature_cols: list) -> Tuple[pd.DataFrame, pd.DataFrame, Dict]:
    """
    Imputasi DataFrame single-patient.
    Returns (df_imputed, imputed_mask, report).
    """
    df = df.sort_values("hr").reset_index(drop=True).copy()
    imputed_mask = df[feature_cols].isna().copy()

    n_total_cells  = len(df) * len(feature_cols)
    n_observed_pre = int((~imputed_mask).sum().sum())
    n_missing_pre  = int(imputed_mask.sum().sum())

    # Cek fitur 100% kosong (general rule untuk semua 13 fitur)
    features_all_empty = []
    for feat in feature_cols:
        if feat not in df.columns or df[feat].isna().all():
            features_all_empty.append(feat)

    if features_all_empty:
        return df, imputed_mask, {
            "n_observed_pre":     n_observed_pre,
            "n_missing_pre":      n_missing_pre,
            "n_total_cells":      n_total_cells,
            "refused":            True,
            "features_all_empty": features_all_empty,
            "permanent_nan":      [],
        }

    # Imputasi
    for col in URINE_FEATS:
        if col in df.columns:
            df[col] = df[col].fillna(0)

    for col in VITAL_FEATS:
        if col in df.columns:
            df[col] = (
                df[col].interpolate(method="linear", limit_direction="both")
                       .ffill().bfill()
            )

    for col in LAB_FEATS:
        if col in df.columns:
            df[col] = df[col].ffill().bfill()

    # Safety net: kalau masih ada NaN, fill 0 (seharusnya tidak terjadi karena sudah cek all_empty)
    permanent_nan = []
    for col in feature_cols:
        if col in df.columns and df[col].isna().any():
            permanent_nan.append(col)
            df[col] = df[col].fillna(0)

    return df, imputed_mask, {
        "n_observed_pre":     n_observed_pre,
        "n_missing_pre":      n_missing_pre,
        "n_total_cells":      n_total_cells,
        "refused":            False,
        "features_all_empty": [],
        "permanent_nan":      permanent_nan,
    }
